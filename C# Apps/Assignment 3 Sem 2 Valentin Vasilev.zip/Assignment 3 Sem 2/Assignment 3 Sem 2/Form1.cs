﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Globalization;
using System.Linq.Expressions;
using System.Data.SqlClient;
using System.Diagnostics;

namespace Assignment_3_Sem_2
{
    
    public partial class Form1 : Form
    {
        Thread serverThread;
        public static List<string> listBoxItems = new List<string>();
        private List<string> compareList = new List<string>();
        private LinkedListStack lls = new LinkedListStack();

        public Form1()
        {
            InitializeComponent();
            VisibilityCheck(false);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Server sr = new Server();
            serverThread = new Thread(sr.Run);
            serverThread.Start();
            VisibilityCheck(true);
        }

        /// <summary>
        /// Here we check for new data from the other thread (I tried doing it with a static Linked List but it caused way too much trouble)
        /// And we also update the listbox 
        /// </summary>
        private void timerLb_Tick(object sender, EventArgs e)
        {
            if (compareList.Count != listBoxItems.Count)
            {
                compareList.Clear();
                for(int i = 0; i < listBoxItems.Count; i++)
                {
                    compareList.Add(listBoxItems[i]);
                }
                lls.push(compareList[compareList.Count-1]);
                ListBox.ObjectCollection objc = lls.AsListBoxCollection();
                lbComLog.Items.Clear();
                foreach (var item in objc)
                {
                    lbComLog.Items.Add(item);
                }            
            }
            
        }


        /// <summary>
        /// Just for better looking code and less CTRL+Vs
        /// </summary>
        private void VisibilityCheck(bool b)
        {
            lbComLog.Visible = b;
            lblComLog.Visible = b;
            lblSensors.Visible = b;
            lbSensors.Visible = b;
            lblNamel.Visible = b;
            lblValuel.Visible = b;
            lblDatel.Visible = b;
            lblUnitl.Visible = b;
            btnStart.Visible = !b;
        }
    }
}
