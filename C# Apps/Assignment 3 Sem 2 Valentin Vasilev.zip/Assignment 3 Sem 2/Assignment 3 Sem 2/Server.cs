﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_3_Sem_2
{
    class Server
    {
        public Server()
        {
            
        }

        /// <summary>
        /// Start the server running on the given IP and Port on a separate thread
        /// </summary>
        public void Run()
        {
            
                try
                {
                    //I have port 42069 on my router forwarded, so
                    //outside clients can also connect and test the server (for assessment, anyone can communicate with it)
                    const string ADDRESS = "192.168.1.180";
                    const int PORT = 555;

                    IPAddress ip = IPAddress.Parse(ADDRESS);
                    IPEndPoint localEndPoint = new IPEndPoint(ip, PORT);
                    Socket listener = new Socket(ip.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                    // Bind to the endpoint
                    listener.Bind(localEndPoint);// Start listening
                    listener.Listen(10);


                    while (true)
                    {
                        
                            Console.WriteLine("Ready");
                            // Get the next connection from the queue or wait    
                            Socket clientSocket = listener.Accept();
                            // Setup streams to read    
                            NetworkStream networkStream = new NetworkStream(clientSocket);
                            StreamReader streamReader = new StreamReader(networkStream);
                            StreamWriter streamWriter = new StreamWriter(networkStream);

                            if (clientSocket.Connected)
                            {
                                streamWriter.WriteLine("Welcome");
                                streamWriter.Flush();
                            }
                            // Keep reading until disconnect
                            string line = streamReader.ReadLine();
                            while (line != null)
                            {
                                bool stop = false;
                                Form1.listBoxItems.Add(line);
                                Console.WriteLine("Client says: " + line);
                                switch (line)
                                {
                                    case "STOP":
                                        stop = true;
                                        break;

                                    case "STaOP":
                                        stop = true;
                                        break;

                                    case "STdsOP":
                                        stop = true;
                                        break;

                                    case "STdOP":
                                        stop = true;
                                        break;
                                }
                                if (stop) break;
                                line = streamReader.ReadLine();
                            }
                            // Client disconnected    
                            Console.WriteLine("Client disconnected");
                        
                    }
                }
                catch (Exception)
                {
                    System.Windows.Forms.MessageBox.Show("This Socket is already taken");
                }
            
            
        }
        
    }
}
