#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void print_binary(char number){
    if (number) {
        print_binary(number >> 1);
        putc((number & 1) ? '1' : '0', stdout);
    }
}

int main (int argc, char** argv)
{
	
	FILE *fIn = fopen(argv[1],"r");
 	FILE *fOut = fopen(argv[2], "w");
	if (fIn == NULL || fOut == NULL)
	{
        printf("Error! opening file");
		exit(1);
	}

	char charInFile;
	u_int8_t lastHighNibble = 0;
	bool highorlow = true;
	while((charInFile = fgetc(fIn)) != EOF)
	{
		
		u_int8_t byte = charInFile;
		u_int8_t endBit,d0,d1,d2,d3,p0,p1,p2;

		endBit = byte >> 7;
		d3 = byte & 0b01000000;
		d3 = d3 >> 6;
		d2 = byte & 0b00100000;
		d2 = d2 >> 5;
		d1 = byte & 0b00010000;
		d1 = d1 >> 4;
		d0 = byte & 0b00001000;
		d0 = d0 >> 3;
		p2 = byte & 0b00000100;
		p2 = p2 >> 2;
		p1 = byte & 0b00000010;
		p1 = p1 >> 1;
		p0 = byte & 0b00000001;

		if(highorlow)	//first half of decoded byte
		{
			if(endBit == 1)		//if endbit is not 0 (we always send it 0), we know what has changed already
			{
				lastHighNibble = 0;
				lastHighNibble = (d3 << 7) | (d2 << 6) | (d1 << 5) | (d0 << 4);
				
			}
			else
			{
				u_int8_t circleLeft = d0 + d1 + d2 + p0,
					 circleRight = d0 + d1 + d3 + p1,
					 circleDown = d1 + d2 + d3 + p2;
				bool probLeft = false,
					 probRight = false,
					 probDown = false;

				if(circleLeft % 2 != 0) probLeft = true;
				if(circleRight % 2 != 0) probRight = true;
				if(circleDown % 2 != 0) probDown = true;
				
				if(probLeft && probRight && probDown)
				{
					//problem is d1
					d1 ^= 0b00000001;
				}
				else if (probLeft && probDown && !probRight)
				{
					//problem is d2
					d2 ^= 0b00000001;
				}
				else if (probLeft && probRight && !probDown)
				{
					//problem is d0
					d0 ^= 0b00000001;
				}
				else if (!probLeft && probRight && probDown)
				{
					//problem is d3
					d3 ^= 0b00000001;
				}
				else
				{
					
				}
				lastHighNibble = 0;
				lastHighNibble = (d3 << 7) | (d2 << 6) | (d1 << 5) | (d0 << 4);
			}			
		}
		else			//second half of decoded byte
		{
			u_int8_t decodedByte = 0;

			if(endBit == 1) 		//if endbit is not 0 (we always send it 0), we know what has changed already
			{			
				decodedByte = (d3 << 3) | (d2 << 2) | (d1 << 1) | d0;
				decodedByte |= lastHighNibble;
			}
			else
			{
				u_int8_t circleLeft = d0 + d1 + d2 + p0,
					 circleRight = d0 + d1 + d3 + p1,
					 circleDown = d1 + d2 + d3 + p2;
				bool probLeft = false,
					 probRight = false,
					 probDown = false;

				if(circleLeft % 2 != 0) probLeft = true;
				if(circleRight % 2 != 0) probRight = true;
				if(circleDown % 2 != 0) probDown = true;
				
				if(probLeft && probRight && probDown)
				{
					//problem is d1
					d1 ^= 0b00000001;
				}
				else if (probLeft && probDown && !probRight)
				{
					//problem is d2
					d2 ^= 0b00000001;
				}
				else if (probLeft && probRight && !probDown)
				{
					//problem is d0
					d0 ^= 0b00000001;
				}
				else if (!probLeft && probRight && probDown)
				{
					//problem is d3
					d3 ^= 0b00000001;
				}
				else
				{
					//problem is p1/p0/p2 - we dont care

				}
				decodedByte = (d3 << 3) | (d2 << 2) | (d1 << 1) | d0;
				decodedByte |= lastHighNibble;
			}		
			fputc(decodedByte, fOut);
		}
		highorlow = !highorlow;	
		
	}
	
	
	fclose(fIn);
	fclose(fOut);
	return 0;
}
