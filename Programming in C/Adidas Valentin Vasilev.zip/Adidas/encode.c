#include <stdio.h>
#include <stdlib.h>
#define buffSize 1024

void encodeByte(u_int8_t c, char* highNibble, char* lowNibble);

int main (int argc, char** argv)
{
	FILE *fIn = fopen(argv[1],"r");
 	FILE *fOut = fopen(argv[2], "w");
	if (fIn == NULL || fOut == NULL)
	{
        printf("Error! opening file");
		exit(1);
	}
	
	char charInFile;
	while((charInFile = fgetc(fIn)) != EOF)
	{
		char high, low;
		encodeByte(charInFile, &high, &low);
		fputc(high, fOut);
		fputc(low, fOut);
	}
	fclose(fIn);
	fclose(fOut);
	return 0;
}


void encodeByte(u_int8_t c, char* highNibble, char* lowNibble)
{
	u_int8_t high = c>>4;
	u_int8_t hd0,hd1,hd2,hd3,hp0,hp1,hp2;

	hd3 = high >> 3;
	hd2 = high & 0b00000100;
	hd2 = hd2 >> 2;
	hd1 = high & 0b00000010;
	hd1 = hd1 >> 1;
	hd0 = high & 0b00000001;
	
	hp0 = (hd0 + hd1 + hd2) % 2;
	hp1 = (hd0 + hd1 + hd3) % 2;
	hp2 = (hd1 + hd2 + hd3) % 2;
	
	//printf("%d%d%d", hp0, hp1, hp2);
	high = 0;
	high = (hd3 << 6) | (hd2 << 5) | (hd1 << 4) | (hd0 << 3) | (hp2 << 2) | (hp1 << 1) | hp0;
	*highNibble = high;

	//printf("%d", high, BIN);
	u_int8_t low = c & 0b00001111;	
	u_int8_t ld0,ld1,ld2,ld3,lp0,lp1,lp2;
	
	ld3 = low >> 3;
	ld2 = low & 0b00000100;
	ld2 = ld2 >> 2;
	ld1 = low & 0b00000010;
	ld1 = ld1 >> 1;
	ld0 = low & 0b00000001;
	
	lp0 = (ld0 + ld1 + ld2) % 2;
	lp1 = (ld0 + ld1 + ld3) % 2;
	lp2 = (ld1 + ld2 + ld3) % 2;

	
	low = 0;
	low = (ld3 << 6) | (ld2 << 5) | (ld1 << 4) | (ld0 << 3) | (lp2 << 2) | (lp1 << 1) | lp0;
	*lowNibble = low;
	//printf("%d%d%d%d", ld3, ld2, ld1, ld0);
}
