#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main (int argc, char** argv)
{
	
	FILE *fIn = fopen(argv[1],"r");
 	FILE *fOut = fopen(argv[2], "w");
	if (fIn == NULL || fOut == NULL)
	{
        printf("Error! opening file");
		exit(1);
	}
	
	
	srand(time(NULL));
	int random = rand() % 8;	

	char charInFile;
	int 	counter0 = 0,counter1 = 0,counter2 = 0,
		counter3 = 0,counter4 = 0,counter5 = 0,
		counter6 = 0,counter7 = 0;

	while((charInFile = fgetc(fIn)) != EOF)
	{
		u_int8_t encoded = charInFile;
		//printf("%c\n", (char)encoded);
		encoded ^= 1 << random;
		//printf("%c\n", (char)encoded);
		random = rand() % 8;
		switch(random)
		{
			case 0:
				counter0++;
				break;
			case 1:
				counter1++;
				break;
			case 2:
				counter2++;
				break;
			case 3:
				counter3++;
				break;
			case 4:
				counter4++;
				break;
			case 5:
				counter5++;
				break;
			case 6:
				counter6++;
				break;
			case 7:
				counter7++;
				break;
		}
		fputc(encoded, fOut);
	}
	printf("Bit 0 was flipped %d times!\n", counter0);
	printf("Bit 1 was flipped %d times!\n", counter1);
	printf("Bit 2 was flipped %d times!\n", counter2);
	printf("Bit 3 was flipped %d times!\n", counter3);
	printf("Bit 4 was flipped %d times!\n", counter4);
	printf("Bit 5 was flipped %d times!\n", counter5);
	printf("Bit 6 was flipped %d times!\n", counter6);
	printf("Bit 7 was flipped %d times!\n", counter7);

	fclose(fIn);
	fclose(fOut);
	return 0;
}
