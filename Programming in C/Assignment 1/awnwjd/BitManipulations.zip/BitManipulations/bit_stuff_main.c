#include <stdio.h>

#include "bit_stuff.h"

int main()
{
    // TODO: implement if you want
    return 0;
}
